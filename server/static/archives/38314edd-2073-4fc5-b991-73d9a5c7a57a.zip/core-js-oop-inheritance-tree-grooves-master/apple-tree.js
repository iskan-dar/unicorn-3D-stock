// const FruitTree = require("./fruit-tree")

class AppleTree extends FruitTree {
  constructor(age = 0, height = 0, fruits, type, growingRate, maxHeight, maxLifeCycle, maturity) {
    super(age, height, fruits, type, growingRate, maxHeight, maxLifeCycle, maturity)
    this.age = age;
    this.height = height;
    this.fruits = [];
    this.harvest = [400, 600];
    this.type = 'apple';
    this.growingRate = 2;
    this.maxHeight = 26;
    this.maxLifeCycle = 45;
    this.maturity = 5;
  }
}

// module.exports = AppleTree
