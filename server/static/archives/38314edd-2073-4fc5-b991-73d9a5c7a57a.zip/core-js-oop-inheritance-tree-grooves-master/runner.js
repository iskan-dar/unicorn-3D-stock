let garden = new TreeGrowe(generateGarden())
const reportsBlock = document.getElementById("reports");

for (let i = 1; i <= 10; i++) {
  garden.groweAllTrees()
  let orangeTrees = garden.allTargetTypeTrees('orange')
  let orangeHarvest = garden.getHarvest('orange')
  let orangeMature = garden.MaturityTrees('orange').length
  let orangeNotMature = garden.notMaturityTrees('orange').length

  let appleTrees = garden.allTargetTypeTrees('apple')
  let appleHarvest = garden.getHarvest('apple')
  let appleMature = garden.MaturityTrees('apple').length
  let appleNotMature = garden.notMaturityTrees('apple').length

  let pearTrees = garden.allTargetTypeTrees('pear')
  let pearHarvest = garden.getHarvest('pear')
  let pearMature = garden.MaturityTrees('pear').length
  let pearNotMature = garden.notMaturityTrees('pear').length
  garden.clear()

  const report = document.createElement("div");
  report.innerHTML = `
      <b>Год ${i}</b>
      <br/>
      Апельсиновые деревья: ${orangeTrees.length} деревьев (незрелые: ${orangeNotMature}, зрелые: ${orangeMature}, погибли: x)
      <br/>
      Урожай ${orangeHarvest} апельсинов
      <br/>
      Яблочные деревья: ${appleTrees.length} деревьев (незрелые: ${appleNotMature}, зрелые: ${appleMature}, погибли: x)
      <br/>
      Урожай ${appleHarvest} яблок
      <br/>
      Грушевые деревья: ${pearTrees.length} деревьев (незрелые: ${pearNotMature}, зрелые: ${pearMature}, погибли: x)
      <br/>
      Урожай ${pearHarvest} груш
      <br/>
      -----------------------------------------------------------------------------------------------
      <br/>
      <br/>
    `;
  reportsBlock.appendChild(report);
}
