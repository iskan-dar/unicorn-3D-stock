// const AppleTree = require('./apple-tree');
// const PearTree = require('./pear-tree');
// const OrangeTree = require('./orange-tree');

function generateGarden() {
  let garden = [];

  for (let i = 0; i < 5; i++) {
    garden.push(new AppleTree(50, 26));
  }

  for (let i = 0; i < 10; i++) {
    garden.push(new AppleTree());
    garden.push(new PearTree());
    garden.push(new AppleTree(5, 14));
    garden.push(new PearTree(20, 15));
    garden.push(new OrangeTree(37, 25));
    garden.push(new PearTree(50, 20));
  }

  for (let i = 0; i < 20; i++) {
    garden.push(new OrangeTree(5, 13));
    garden.push(new OrangeTree(20, 25));
    garden.push(new AppleTree(20, 23));
    garden.push(new AppleTree(37, 26));
    garden.push(new PearTree(37, 20));
    garden.push(new OrangeTree(50, 25));
  }

  return garden;
}


class TreeGrowe {
  constructor(garden = []) {
    this.garden = garden;
  };

  groweAllTrees() {
    return this.garden.map(el => el.passGrowingSeason())
  }

  allTrees() {
    return this.garden;
  };

  allTargetTypeTrees(type) {
    return this.garden.filter(el => el.type == type.toLowerCase())
  }

  MaturityTrees(type) {
    return (this.garden.filter(el => el.type == type)).filter(el => el.isMature())
  }

  notMaturityTrees(type) {
    return (this.garden.filter(el => el.type == type)).filter(el => !el.isMature())
  }

  getHarvest(type) {
    return ((this.garden.filter(el => el.type == type)).map(el => el.fruits.length)).reduce((acc, val) => acc + val, 0)
  }

  clear() {
    return this.garden.map(el => el.fruits = [])
  }
}
