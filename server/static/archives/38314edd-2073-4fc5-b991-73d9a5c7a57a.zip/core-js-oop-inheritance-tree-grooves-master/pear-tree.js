// const FruitTree = require("./fruit-tree")

class PearTree extends FruitTree {
  constructor(age = 0, height = 0, fruits, type, growingRate, maxHeight, maxLifeCycle, maturity) {
    super(age, height, fruits, type, growingRate, maxHeight, maxLifeCycle, maturity)
    this.age = age;
    this.height = height;
    this.fruits = [];
    this.harvest = [175, 225]
    this.type = 'pear';
    this.growingRate = 2.5;
    this.maxHeight = 20;
    this.maxLifeCycle = 40;
    this.maturity = 5;
  }
}

// module.exports = PearTree
