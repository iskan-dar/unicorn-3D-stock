// const Pear = require('./pear')
// const Apple = require('./apple')
// const Orange = require('./orange')

class FruitTree {
  constructor(age = 0, height = 0, fruits = [], diameter = 0, harvest = [], type = 'unknown', growingRate = 0, maxHeight = Infinity, maxLifeCycle = Infinity, maturity = Number) {
    this.age = age;
    this.height = height;
    this.fruits = fruits;
    this.diameter = diameter;
    this.harvest = harvest;
    this.type = type;
    this.growingRate = growingRate;
    this.maxHeight = maxHeight;
    this.maxLifeCycle = maxLifeCycle;
    this.maturity = maturity;
  }

  passGrowingSeason() {
    this.age = this.age + 1
    if (this.height < 20) {
      this.height = this.height + this.growingRate
    }
    if (this.age >= this.maturity) {
      let rand = Math.floor(this.harvest[0] + Math.random() * (this.harvest[1] + 1 - this.harvest[0]))
      for (let i = 0; i < rand; i++) {
        if (this.type === 'pear') {
          let pear = new Pear()
          this.fruits.push(pear)
        }
        if (this.type === 'apple') {
          let apple = new Apple()
          this.fruits.push(apple)
        }
        if (this.type === 'orange') {
          let orange = new Orange()
          this.fruits.push(orange)
        }
      }
    }
    return this
  }

  isMature() {
    return this.age >= this.maturity ? true : false
  }

  hasFruits() {
    return this.fruits.length > 0 ? true : false;
  }

  pickAnFruit() {
    if (this.hasFruits()) {
      return this.fruits.pop()
    }
    if (!this.hasFruits()) {
      throw Error('This tree has no fruits');
    }
  }

  isDead() {
    return this.age >= this.maxLifeCycle ? true : false
  }

}

// module.exports = FruitTree
