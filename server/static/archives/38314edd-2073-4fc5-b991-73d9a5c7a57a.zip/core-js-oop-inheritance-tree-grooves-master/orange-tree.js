// const FruitTree = require("./fruit-tree")

class OrangeTree extends FruitTree {
  constructor(age = 0, height = 0, fruits, type, growingRate, maxHeight, maxLifeCycle, maturity) {
    super(age, height, fruits, type, growingRate, maxHeight, maxLifeCycle, maturity)
    this.age = age;
    this.height = height;
    this.fruits = [];
    this.harvest = [100, 300]
    this.type = 'orange';
    this.growingRate = 2.5;
    this.maxHeight = 25;
    this.maxLifeCycle = 100;
    this.maturity = 6;
  }
}

// module.exports = OrangeTree

