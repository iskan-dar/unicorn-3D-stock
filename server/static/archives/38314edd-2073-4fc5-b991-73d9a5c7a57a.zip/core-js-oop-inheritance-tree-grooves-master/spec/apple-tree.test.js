const AppleTree = require('../apple-tree');


// Test-Driven Development
describe('AppleTree', () => {
  let tree;

  beforeEach(() => {
    tree = new AppleTree();
  });

  describe('age', () => {
    test('has an age', () => {
      expect(tree.age).toBe(0);
    });
  });

  describe('height', () => {
    test('has a height', () => {
      expect(tree.height).toBe(0);
    });
  });

  // Убери 'x' из `xdescribe`, чтобы включить эти тесты.
  describe('passGrowingSeason', () => {
    beforeEach(() => {
      tree = new AppleTree(4, 8);
    });
    test('should change the tree age and height', () => {
      tree.passGrowingSeason();
      expect(tree.age).toBe(5);
      expect(tree.height).toBe(10);
    });

    test('should make the tree grow', () => {
      // This should be more explicit. How much should the tree grow?
      tree.passGrowingSeason();
      tree.passGrowingSeason();
      expect(tree.height).toBe(12);
    });

    // If the tree is old enough to bear fruit
    test('should cause the tree to produce apples', () => {
      tree.passGrowingSeason();
      expect(tree.fruits.length > 0).toBe(true);
    });
  });

  describe('isMature', () => {
    beforeEach(() => {
      tree = new AppleTree(4);
    });
    test('returns true if tree is old enough to bear fruit', () => {
      tree.passGrowingSeason();
      expect(tree.isMature()).toBeTruthy();
    });

    test('returns false if tree is not old enough to bear fruit', () => {
      expect(tree.isMature()).toBeFalsy();
    });
  });

  describe('isDead', () => {
    beforeEach(() => {
      tree = new AppleTree(44);
    });
    test('should return false for an alive tree', () => {
      expect(tree.age).toBe(44);
      expect(tree.isDead()).toBe(false);
    });

    test('should return true for a dead tree', () => {
      tree.passGrowingSeason();
      expect(tree.age).toBe(45);
      expect(tree.isDead()).toBe(true);
    });
  });

  describe('hasApples', () => {
    beforeEach(() => {
      tree = new AppleTree(10);
    });
    test('should return true if the tree has apples', () => {
      tree.passGrowingSeason();
      expect(tree.hasFruits()).toBe(true);
    });

    test('should return false if the tree has no apples', () => {
      expect(tree.hasFruits()).toBe(false);
    });
  });

  describe('pickAnApple', () => {
    beforeEach(() => {
      tree = new AppleTree(14);
    });
    test('should return an apple from the tree', () => {
      tree.passGrowingSeason();
      expect(tree.pickAnFruit()).toBe(Object);
    });

    test('the returned apple should no longer be on the tree', () => {
      tree.passGrowingSeason();
      expect(tree.fruits).not.toContain(tree.pickAnFruit());
    });
  });
});
