const path = require('path');
const Converter = require('../Converter');
const dictionary = require('../dictionary');

describe('Конвертер', () => {
  let converter;
  const folderPath = path.join(__dirname, '..');
  const fileName = 'translitThis.txt';

  beforeEach(() => {
    converter = new Converter({ folderPath, dictionary });
  });

  describe('метод readFile', () => {
    it('возвращает промис', () => {
      const promise = converter.readFile(fileName);
      expect(typeof promise.then).toBe('function');
    });

    it('возвращает промис, который резолвится в содержимое файла', async () => {
      const fileData = await converter.readFile(fileName);
      expect(fileData).toBe('Необходимо перевести этот текст в транслит');
    });
  });

  describe('метод transliterate', () => {
    it('возвращает промис', () => {
      const promise = converter.transliterate(fileName);
      expect(typeof promise.then).toBe('function');
    });

    it('возвращает промис, который резолвится в транслитерированное содержимое файла', async () => {
      const translitFileData = await converter.transliterate(fileName);
      expect(translitFileData).toBe('Neobhodimo perevesti etot tekst v translit');
    });
  });
});
