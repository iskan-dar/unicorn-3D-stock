class Converter {
  constructor({ folderPath, dictionary }) {
    this.folderPath = folderPath;
    this.dictionary = dictionary;
  }
}

module.exports = Converter;
