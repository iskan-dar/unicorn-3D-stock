class BondAnalyzer {
  constructor(bondList) {
    this.bondList = bondList;
  }

  getMeanOpenPrice() {
    const reducer = (totalOpenPrice, bond) => totalOpenPrice + bond.openPrice;
    return this.bondList.reduce(reducer, 0) / this.bondList.length;
  }

  getMinimumOpenPrice() {
    const sortedBondList = this.bondList
      .slice()
      .sort((bondA, bondB) => bondA.openPrice - bondB.openPrice);

    return sortedBondList[0].openPrice;
  }
}

module.exports = BondAnalyzer;
