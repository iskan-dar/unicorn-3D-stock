class StockAnalyzer {
  constructor(stockList) {
    this.stockList = stockList;
  }

  getMeanOpenPrice() {
    const reducer = (totalOpenPrice, stock) => totalOpenPrice + stock.openPrice;
    return this.stockList.reduce(reducer, 0) / this.stockList.length;
  }

  getMinimumOpenPrice() {
    const sortedStockList = this.stockList
      .slice()
      .sort((stockA, stockB) => stockA.openPrice - stockB.openPrice);

    return sortedStockList[0].openPrice;
  }
}

module.exports = StockAnalyzer;
