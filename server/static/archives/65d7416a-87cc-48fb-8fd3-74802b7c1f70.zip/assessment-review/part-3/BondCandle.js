class BondCandle {
  constructor(duration, issuer, openPrice, closePrice, lowPrice, highPrice) {
    this.duration = duration;
    this.issuer = issuer;
    this.openPrice = openPrice;
    this.closePrice = closePrice;
    this.lowPrice = lowPrice;
    this.highPrice = highPrice;
  }

  getParams() {
    return [
      this.openPrice,
      this.closePrice,
      this.lowPrice,
      this.highPrice,
    ];
  }
}

module.exports = BondCandle;
