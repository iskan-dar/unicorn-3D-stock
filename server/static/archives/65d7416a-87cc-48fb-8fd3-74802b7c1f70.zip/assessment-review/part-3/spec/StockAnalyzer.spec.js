const StockAnalyzer = require('../StockAnalyzer');
const StockCandle = require('../StockCandle');

describe('Анализатор свечей акций', () => {
  let candles;
  beforeEach(() => {
    candles = [
      new StockCandle('MSFT', 'Microsoft Corporation', 219, 220, 223, 216),
      new StockCandle('MSFT', 'Microsoft Corporation', 222, 224, 222, 224),
      new StockCandle('MSFT', 'Microsoft Corporation', 220, 230, 219, 235),
    ];
  });

  it('Находит среднее цен открытия по всем свечам', () => {
    const analyzer = new StockAnalyzer(candles);
    expect((analyzer.getMeanOpenPrice()).toFixed(2)).toBe('220.33');
  });

  it('Находит минимальную цену открытия среди всех свечей', () => {
    const analyzer = new StockAnalyzer(candles);
    expect(analyzer.getMinimumOpenPrice()).toBe(219);
  });
});
