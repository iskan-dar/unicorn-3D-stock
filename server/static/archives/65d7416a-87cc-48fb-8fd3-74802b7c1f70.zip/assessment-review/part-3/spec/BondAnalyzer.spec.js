const BondAnalyzer = require('../BondAnalyzer');
const BondCandle = require('../BondCandle');

describe('Анализатор свечей облигаций', () => {
  let candles;
  beforeEach(() => {
    candles = [
      new BondCandle('1Y', 'Austria', 103.718, 103.670, 103.730, 103.663),
      new BondCandle('1Y', 'Austria', 103.723, 103.770, 103.720, 103.770),
      new BondCandle('1Y', 'Austria', 103.700, 103.759, 103.698, 103.760),
    ];
  });

  it('Находит среднее цен открытия по всем свечам', () => {
    const analyzer = new BondAnalyzer(candles);
    expect((analyzer.getMeanOpenPrice()).toFixed(3)).toBe('103.714');
  });

  it('Находит минимальную цену открытия среди всех свечей', () => {
    const analyzer = new BondAnalyzer(candles);
    expect(analyzer.getMinimumOpenPrice()).toBe(103.700);
  });
});
