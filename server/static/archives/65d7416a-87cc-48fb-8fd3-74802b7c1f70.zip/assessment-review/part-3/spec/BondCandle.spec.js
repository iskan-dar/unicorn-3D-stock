const BondCandle = require('../BondCandle');

describe('Свеча облигации', () => {
  it('позволяет задать параметры свечи', () => {
    const duration = '1Y';
    const issuer = 'Austria';
    const openPrice = 103.718;
    const closePrice = 103.930;
    const lowPrice = 103.408;
    const highPrice = 103.935;
    const candle = new BondCandle(
      duration,
      issuer,
      openPrice,
      closePrice,
      lowPrice,
      highPrice,
    );

    expect(candle.duration).toBe(duration);
    expect(candle.issuer).toBe(issuer);
    expect(candle.openPrice).toBe(openPrice);
    expect(candle.closePrice).toBe(closePrice);
    expect(candle.lowPrice).toBe(lowPrice);
    expect(candle.highPrice).toBe(highPrice);
  });

  it('позволяет получить параметры свечи', () => {
    const duration = '1Y';
    const issuer = 'Austria';
    const openPrice = 103.718;
    const closePrice = 103.930;
    const lowPrice = 103.408;
    const highPrice = 103.935;
    const candle = new BondCandle(
      duration,
      issuer,
      openPrice,
      closePrice,
      lowPrice,
      highPrice,
    );

    expect(candle.getParams()).toEqual([openPrice, closePrice, lowPrice, highPrice]);
  });
});
