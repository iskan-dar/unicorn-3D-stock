const StockCandle = require('../StockCandle');

describe('Свеча акции', () => {
  it('позволяет задать параметры свечи', () => {
    const symbol = 'MSFT';
    const issuer = 'Microsoft Corporation';
    const openPrice = 219;
    const closePrice = 224;
    const lowPrice = 215;
    const highPrice = 226;
    const candle = new StockCandle(
      symbol,
      issuer,
      openPrice,
      closePrice,
      lowPrice,
      highPrice,
    );

    expect(candle.symbol).toBe(symbol);
    expect(candle.issuer).toBe(issuer);
    expect(candle.openPrice).toBe(openPrice);
    expect(candle.closePrice).toBe(closePrice);
    expect(candle.lowPrice).toBe(lowPrice);
    expect(candle.highPrice).toBe(highPrice);
  });

  it('позволяет получить параметры свечи', () => {
    const symbol = 'MSFT';
    const issuer = 'Microsoft Corporation';
    const openPrice = 219;
    const closePrice = 224;
    const lowPrice = 215;
    const highPrice = 226;
    const candle = new StockCandle(
      symbol,
      issuer,
      openPrice,
      closePrice,
      lowPrice,
      highPrice,
    );

    expect(candle.getParams()).toEqual([openPrice, closePrice, lowPrice, highPrice]);
  });
});
