class Ticket {
  constructor(number, price) {
    this.number = number;
    this.price = price;
  }
}

module.exports = Ticket;
