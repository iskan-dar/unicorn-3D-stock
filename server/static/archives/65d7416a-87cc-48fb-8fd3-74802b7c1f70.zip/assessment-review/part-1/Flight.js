class Flight {
  constructor({ destination, ticketList }) {
    this.destination = destination;
    this.ticketList = ticketList;
    this.passengers = [];
    this.baggage = [];
  }

  ticketControl(people) {
    const ticketNumbers = this.ticketList.map((ticket) => ticket.number);

    const passengers = people.filter(
      (person) => ticketNumbers.includes(person.ticket.number),
    );

    const passengersWithPass = passengers.map(
      (passenger) => ({
        ...passenger, // spread-оператор
        hasBoardingPass: true,
      }),
    );

    return passengersWithPass;
  }
}

module.exports = Flight;
