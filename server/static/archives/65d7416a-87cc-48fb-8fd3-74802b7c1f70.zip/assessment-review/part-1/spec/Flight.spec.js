const Flight = require('../Flight');
const Ticket = require('../Ticket');
const Passenger = require('../Passenger');

describe('Авиарейс', () => {
  let flight;
  let people;
  let passengers;

  let ticket1;
  let ticket2;
  let ticket3;
  let ticket4;
  let ticket5;

  let john;
  let yana;
  let boleslav;
  let alevtina;

  beforeEach(() => {
    ticket1 = new Ticket('71027174523', 120);
    ticket2 = new Ticket('62548104637', 120);
    ticket3 = new Ticket('84620962649', 120);
    ticket4 = new Ticket('85246295612', 120);
    ticket5 = new Ticket('09384363547', 120);

    john = new Passenger({ name: 'John Smith', ticket: ticket1, baggage: ['notebook', 'bag'] });
    yana = new Passenger({ name: 'Байкова Яна', ticket: ticket2, baggage: ['frying pan', 'backpack'] });
    boleslav = new Passenger({ name: 'Зеленов Болеслав', ticket: ticket3, baggage: ['cat', 'backpack'] });
    alevtina = new Passenger({ name: 'Уланова Алевтина', ticket: ticket5, baggage: ['fishing rod', 'backpack'] });

    people = [john, yana, boleslav, alevtina];

    flight = new Flight({
      destination: 'Милан',
      ticketList: [ticket1, ticket2, ticket3, ticket4],
    });
  });

  it('содержит список билетов', () => {
    expect(flight.ticketList.length).toBe(4);
  });

  it('содержит список пассажиров, находящихся в самолёте', () => {
    expect(flight.passengers.length).toBe(0);
  });

  it('содержит информацию о багажном отделении самолёта', () => {
    expect(flight.baggage.length).toBe(0);
  });

  describe('Метод ticketControl', () => {
    beforeEach(() => {
      passengers = flight.ticketControl(people);
    });

    it('возвращает массив пассажиров, допущенных к рейсу', () => {
      expect(Array.isArray(passengers)).toBe(true);
    });

    it('выдаёт посадочные талоны всем, у кого есть билет на этот полёт', () => {
      expect(
        passengers.every((passenger) => passenger.hasBoardingPass),
      ).toBe(true);
    });

    it('[необязательно] не мутирует исходные данные', () => {
      expect(
        people.some((person) => person.hasBoardingPass),
      ).toBe(false);
    });

    it('не выдаёт посадочный талон пассажирам без билета на этот рейс', () => {
      const passengerAlevtina = passengers.find(
        (passenger) => passenger.name === 'Уланова Алевтина',
      );
      expect(passengerAlevtina).toBeUndefined();
    });
  });

  describe('Метод registerBaggage', () => {
    beforeEach(() => {
      passengers = flight.registerBaggage(people);
    });

    it('возвращает массив пассажиров, сдавших багаж', () => {
      expect(Array.isArray(passengers)).toBe(true);
    });

    it('забирает вещи у пассажиров этого рейса', () => {
      const holdsNoBaggage = (passenger) => passenger.baggage.length === 0;

      expect(passengers.every(holdsNoBaggage)).toBe(true);
    });

    it('переносит вещи пассажиров в багажное отделение самолёта', () => {
      const flightBaggage = [
        { ticket: ticket1, baggage: ['notebook', 'bag'] },
        { ticket: ticket2, baggage: ['frying pan', 'backpack'] },
        { ticket: ticket3, baggage: ['cat', 'backpack'] },
      ];

      expect(flight.baggage).toStrictEqual(flightBaggage);
    });

    it('игнорирует вещи пассажиров с билетом на другой рейс', () => {
      const baggageEntry = {
        ticket: alevtina.ticket,
        baggage: alevtina.baggage,
      };

      expect(flight.baggage).toEqual(
        expect.not.arrayContaining([baggageEntry]),
      );
    });

    it.skip('[необязательно] не мутирует исходные данные', () => {
      expect(
        people.some((person) => person.baggage.length === 0),
      ).toBe(false);
    });
  });

  describe('Метод board', () => {
    beforeEach(() => {
      flight.board(people);
    });

    it('наполняет салон самолёта пассажирами', () => {
      expect(flight.passengers.length).not.toBe(0);
    });

    it('пропускает в салон только людей с посадочным талоном', () => {
      const hasBoardingPass = (passenger) => passenger.hasBoardingPass;
      expect(flight.passengers.every(hasBoardingPass)).toBe(true);
    });

    it('пропускает в салон только людей со сданным багажом', () => {
      const noPendingBaggage = (passenger) => passenger.baggage.length === 0;
      expect(flight.passengers.every(noPendingBaggage)).toBe(true);
    });

    it('не допускает к посадке людей с билетом на другой рейс', () => {
      const alevtinaOnBoard = {
        ...alevtina,
        hasBoardingPass: true,
        baggage: [],
        isBoarded: true,
      };

      expect(flight.passengers).toEqual(
        expect.not.arrayContaining([alevtinaOnBoard]),
      );
    });
  });

  describe('Метод claimBaggage', () => {
    beforeEach(() => {
      flight.passengers = [
        { ticket: john.ticket, baggage: [] },
        { ticket: yana.ticket, baggage: [] },
        { ticket: boleslav.ticket, baggage: [] },
      ];

      flight.baggage = [
        { ticket: john.ticket, baggage: john.baggage },
        { ticket: yana.ticket, baggage: yana.baggage },
        { ticket: boleslav.ticket, baggage: boleslav.baggage },
      ];

      passengers = flight.claimBaggage();
    });

    it('возвращает массив пассажиров, получивших багаж', () => {
      expect(Array.isArray(passengers)).toBe(true);
    });

    it('раздаёт багаж обратно пассажирам', () => {
      const hasBaggageBack = (passenger) => passenger.baggage.length > 0;
      expect(passengers.every(hasBaggageBack)).toBe(true);
    });

    it('опустошает багажное отделение самолёта', () => {
      expect(flight.baggage.length).toBe(0);
    });
  });
});
