const Passenger = require('../Passenger');

describe('Пассажир', () => {
  let regularPassenger;
  let likesToTravelLight;

  beforeEach(() => {
    regularPassenger = new Passenger({ name: 'John Smith', baggage: ['notebook', 'bag'] });
    likesToTravelLight = new Passenger({ name: 'Rina Bousfield' });
  });

  it('может быть без багажа', () => {
    const emptyBaggage = [];
    expect(likesToTravelLight.baggage).toStrictEqual(emptyBaggage);
  });

  it('изначально не имеет посадочного талона', () => {
    expect(regularPassenger.hasBoardingPass).toBe(false);
  });

  it('изначально не сидит в самолёте', () => {
    expect(regularPassenger.isBoarded).toBe(false);
  });

  describe('hasPendingBaggage', () => {
    it('возвращает true, если у пассажира есть багаж для сдачи перед посадкой', () => {
      expect(regularPassenger.baggage.length).toBe(2);
      expect(regularPassenger.hasPendingBaggage).toBe(true);
    });

    it('возвращает false, если у пассажира нет багажа', () => {
      expect(likesToTravelLight.baggage.length).toBe(0);
      expect(likesToTravelLight.hasPendingBaggage).toBe(false);
    });

    it('[необязательно] реализован не как собственное свойство объекта', () => {
      const isImplemented = Passenger.toString().includes('hasPendingBaggage');
      const isExtraProperty = Object.prototype.hasOwnProperty.call(
        regularPassenger,
        'hasPendingBaggage',
      );

      expect(isImplemented).toBe(true);
      expect(isExtraProperty).toBe(false);
    });
  });
});
