class Passenger {
  constructor({ name, ticket, baggage = [] }) {
    this.name = name;
    this.ticket = ticket;
    this.baggage = baggage;
    this.hasBoardingPass = false;
    this.isBoarded = false;
    // собственное свойство
    // this.hasPendingBaggage = this.baggage.length > 0;
  }

  // виртуальное свойство, рассчитывается "на лету"
  // геттер, будет вызван при обращении как к свойству (this.hasPendingBaggage)
  get hasPendingBaggage() {
    // return Boolean(this.baggage.length);
    return this.baggage.length > 0;
  }

  // сеттер — вызывается при попытке записать в свойство (несуществующее) (this.foo = 'bar')
}

module.exports = Passenger;
