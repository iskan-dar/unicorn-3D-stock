require('dotenv').config();
const { PORT } = process.env;
const express = require('express');
const mainRouter = require('./routes/main.js');


// Импортируем созданный в отдельный файлах рутеры.
const app = express();
app.use(express.urlencoded({ extended: true }));
// Подключаем middleware, которое позволяет читать переменные JavaScript, сохранённые в формате JSON в body HTTP-запроса.
app.use(express.json());

app.use((req, res, next) => {
  const accessList = ["http://localhost:3000", "http://localhost:3001"];
  const origin = req.get("origin");
  if (accessList.includes(origin)) {
    res.header("Access-Control-Allow-Origin", origin);
    res.header("Access-Control-Allow-Headers", "Content-type");
    res.header("Access-Control-Allow-Credentials", true);
  }
  next();
});

app.use('/main', mainRouter);

app.listen(PORT, () => {
  console.log(`server started PORT: ${PORT}`);
});
