import { useDispatch, useSelector } from 'react-redux';
import { deleteOneTodo } from '../../redux/action/todoAC';
import style from "./style.module.css";


export default function TodoItem({todo}) {
  const allTodo = useSelector((store)=>store.allTodo);
  const dispatch = useDispatch();

  const deleteHandler = async () => {
    dispatch(deleteOneTodo(todo))
  }
  return (
    <div className={style.taskBox}>
    <div className={style.formCheck}>
        <div className={style.title}>{todo.task}</div>
        <div className={style.btnBox}>
            <input className={style.formCheckInput} type="checkbox" id="flexCheckChecked" />
            <div className={style.edButton}>EDIT</div>
            <div onClick={deleteHandler} className={style.delButton}>DELETE</div>
        </div>
    </div>
</div>
  )
}
