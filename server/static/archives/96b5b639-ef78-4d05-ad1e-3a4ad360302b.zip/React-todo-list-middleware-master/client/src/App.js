import "./App.css";
import TodoForm from "./components/TodoForm/TodoForm";
import TodoList from "./components/TodoList/TodoList";
// import {Routes, Route} from "react-router-dom";

function App() {
  return (
    <>
      <header className="App-header">
        <TodoForm />
        <TodoList />
      </header>
    </>
  );
}

export default App;
