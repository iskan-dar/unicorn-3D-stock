const initState = {
  todoInput: {},
  allTodo: [],
};
export default initState;
