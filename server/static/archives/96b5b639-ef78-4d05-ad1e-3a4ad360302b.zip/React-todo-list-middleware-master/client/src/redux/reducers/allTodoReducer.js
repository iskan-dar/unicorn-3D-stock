import initState from "../initState";

const allTodoReducer = (state = initState, action) => {
  const { type, payload } = action;
  switch (type) {
    case "GET_ALL_TODO":
      return { ...state, allTodo: payload };

    case "ADD_TODO":
      return { ...state, allTodo: [...state.allTodo, payload] };

    case "DELETE_TODO":
      return { ...state, allTodo: [...state.allTodo.filter((element) => element !== payload)] };

    default:
      return state;
  }
};

export default allTodoReducer;
