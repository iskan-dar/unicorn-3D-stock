import { combineReducers } from 'redux';
import allTodoReducer from './allTodoReducer';
import todoReducer from './todoReducer';

const rootReducer = combineReducers({
  todoInput: todoReducer,
  allTodo: allTodoReducer
});

export default rootReducer;
