const UserDto = {
  userName: 'sergey',
  email: 'serg32-32@mail.ru',
  id: 6,
  isActive: false
};
console.log(...UserDto);
