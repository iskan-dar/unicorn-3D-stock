import React from 'react';
import TodoForm from "../TodoForm/TodoForm";
import TodoList from "../TodoList/TodoList";

export default function MainPage() {
  return (
    <>
    <header className="App-header">
        <TodoForm />
        <TodoList />
      </header>
    </>
  )
}
