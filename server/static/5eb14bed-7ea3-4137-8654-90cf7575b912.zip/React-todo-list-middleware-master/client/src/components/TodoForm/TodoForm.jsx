import React from "react";
import style from "./style.module.css";
import { useDispatch, useSelector } from "react-redux";
import { userTyping, submitTodo } from "../../redux/action/todoAC";

function TodoForm() {
  const dispatch = useDispatch();
  const todoInput = useSelector((store) => store.todoInput);

  const changeHandler = (e) => {
    dispatch(userTyping(e));
  };

  const submitHandler = async (e) => {
    e.preventDefault();
    dispatch(submitTodo(todoInput));
  };
  console.log(todoInput);
  return (
    <>
      <form onSubmit={submitHandler} className={style.mainBox}>
        <input
          onChange={changeHandler}
          type="text"
          className={style.input}
          placeholder="What needs to be done?"
          name="text"
          value={todoInput.text || ''}
        />
        <button type="submit" className={style.btn}>
          Add
        </button>
      </form>
    </>
  );
}

export default TodoForm;
