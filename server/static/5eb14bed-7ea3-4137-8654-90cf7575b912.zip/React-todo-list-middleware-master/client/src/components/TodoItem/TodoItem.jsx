import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  deleteOneTodo,
  changeOneTodoStatus,
  editOneTodo,
} from "../../redux/action/todoAC";
import style from "./style.module.css";

export default function TodoItem({ todo }) {
  const allTodo = useSelector((store) => store.allTodo);
  const dispatch = useDispatch();
  const [editBtnState, setEditBtnState] = useState(false);
  const [input, setInput] = useState(todo.task);

  const deleteHandler = async () => {
    dispatch(deleteOneTodo(todo));
  };

  const checkBoxHandler = async () => {
    dispatch(changeOneTodoStatus(todo));
  };

  const renderEditFormHandler = async () => {
    setEditBtnState(!editBtnState);
  };

  const check = (data) => {
    const falseClass = style.title;
    const trueClass = style.titleDone;
    return data.status ? trueClass : falseClass;
  };

  const editHandler = (input) => {
    todo.task = input;

    dispatch(editOneTodo(todo));
    setEditBtnState();
  };

  return (
    <div className={style.taskBox}>
      <div className={style.formCheck}>
        {editBtnState ? (
          <input
            className={style.editInput}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
        ) : (
          <div className={check(todo)}>{todo.task}</div>
        )}

        <div className={style.btnBox}>
          <input
            onClick={checkBoxHandler}
            className={style.formCheckInput}
            type="checkbox"
            id="flexCheckChecked"
            defaultChecked={todo.status}
          />

          {editBtnState ? (
            <button
              className={style.editBtn}
              type="button"
              onClick={() => editHandler(input)}>
              SAVE
            </button>
          ) : (
            <div onClick={renderEditFormHandler} className={style.edButton}>
              EDIT
            </div>
          )}

          <div onClick={deleteHandler} className={style.delButton}>
            DELETE
          </div>
        </div>
      </div>
    </div>
  );
}
