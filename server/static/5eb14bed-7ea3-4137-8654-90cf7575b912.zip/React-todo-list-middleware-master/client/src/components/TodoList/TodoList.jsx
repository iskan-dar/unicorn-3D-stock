import React, { useEffect } from 'react';
import TodoItem from '../TodoItem/TodoItem';
import { useDispatch, useSelector } from "react-redux";
import { getAllTodo } from "../../redux/action/todoAC";

export default function TodoList() {
  const dispatch = useDispatch();
  const allTodo = useSelector((store) => store.allTodo);
  
  useEffect(()=>{
    dispatch(getAllTodo());
  },[dispatch]);
  
  return (
    <>
    {!!allTodo?.allTodo?.length &&
    allTodo.allTodo.map((element) => <TodoItem todo={element} key={element.id}/>)}
    
    </>
  )
}
