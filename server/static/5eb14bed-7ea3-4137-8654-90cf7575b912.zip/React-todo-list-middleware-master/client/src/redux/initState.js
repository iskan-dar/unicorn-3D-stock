const initState = {
  todoInput: {},
  allTodo: [],
  registerInputs: {},
  loginInputs: {},
  user: '',
};
export default initState;
