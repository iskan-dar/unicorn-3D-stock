import axios from 'axios';

export const userTyping = (data) => {
  return {type: 'USER_TYPING_TODO', payload: {[data.target.name]: data.target.value}};
};

export const clearTyping = (data) => {
  return {type: 'CLEAR_INPUTS_TODO', payload: {}};
};

export const allTodoState = (data) => {
  return {type: "GET_ALL_TODO", payload: data};
};

export const addTodo = (data) => {
  return {type: "ADD_TODO", payload: data};
};

export const deleteTodo = (data) => {
  return { type: "DELETE_TODO", payload: data};
};

export const changeStatusTodo = (data) => {
  return { type: "CHANGE_STATUS_TODO", payload: data};
};

export const editTodo = (data) => {
  return { type: "EDIT_TODO", payload: data};
};

export const submitTodo = (todoInputs) => async(dispatch) => {
  const response = await axios.post('http://localhost:3001/main/writeTodo', todoInputs);
  dispatch(clearTyping());
  dispatch(addTodo(response.data));
};

export const getAllTodo = () => async(dispatch) => {
  const allTodoResponse = await axios.get('http://localhost:3001/main/getTodo');
  dispatch(allTodoState(allTodoResponse.data));
};

export const deleteOneTodo = (todo) => async(dispatch) => {
  const deleteTodoServer = await axios.post('http://localhost:3001/main/deleteTodo', todo);
  dispatch(deleteTodo(todo));
};

export const changeOneTodoStatus = (todo) => async(dispatch) => {
  const changeOneTodoStatusServer = await axios.post('http://localhost:3001/main/changeStatusTodo', todo);
  dispatch(changeStatusTodo(todo.id));
};

export const editOneTodo = (todo) => async(dispatch) => {
  const editOneTodoServer = await axios.post('http://localhost:3001/main/editTodo', todo);
  dispatch(editTodo(todo.id));
};
