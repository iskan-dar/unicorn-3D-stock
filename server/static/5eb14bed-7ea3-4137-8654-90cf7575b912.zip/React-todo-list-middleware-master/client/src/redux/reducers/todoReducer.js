import initState from "../initState";

const todoReducer = (state = initState, action) => {
  const { type, payload } = action;
  switch (type) {
    case "USER_TYPING_TODO":
      return { ...state, ...payload };

    case "CLEAR_INPUTS_TODO":
      return { ...payload };

    default:
      return state;
  }
};

export default todoReducer;
