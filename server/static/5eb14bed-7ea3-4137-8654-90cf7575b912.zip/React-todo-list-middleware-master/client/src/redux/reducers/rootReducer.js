import { combineReducers } from 'redux';
import allTodoReducer from './allTodoReducer';
import todoReducer from './todoReducer';
import registerReducer from './registerReducer';
import loginReducer from './loginReducer';
import userReducer from './userReducer';

const rootReducer = combineReducers({
  todoInput: todoReducer,
  allTodo: allTodoReducer,
  user: userReducer,
  registerInputs: registerReducer,
  loginInputs: loginReducer,
});

export default rootReducer;
