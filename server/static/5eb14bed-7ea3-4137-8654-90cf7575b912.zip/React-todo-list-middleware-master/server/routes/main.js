const router = require("express").Router();
const { Task } = require("../db/models");

// ручка регистрации
router.post("/writeTodo", async (req, res) => {
  const { text } = req.body;
  try {
    if (text !== undefined && text !== "") {
      const newTodo = await Task.create({ task: text, status: false });
      res.json(newTodo);
    }
  } catch (err) {
    console.error(err);
    res.sendStatus(400);
  }
});

router.get("/getTodo", async (req, res) => {
  try {
    const allTodo = await Task.findAll({ raw: true });
    res.json(allTodo);
  } catch (err) {
    console.error(err);
    res.sendStatus(400);
  }
});

router.post("/deleteTodo", async (req, res) => {
  const {id} = req.body;
  try {
    const deleteTodo = await Task.destroy({where: {id: id}, raw: true });
    res.sendStatus(200);
  } catch (err) {
    console.error(err);
    res.sendStatus(400);
  }
});

router.post("/changeStatusTodo", async (req, res) => {
  const {id, status} = req.body;
  console.log(req.body);
  console.log(id, status);
  const reversStatus = !status
  try {
    const changeStatusTodo = await Task.findOne({ where: {id: id} });
    await changeStatusTodo.update({status: reversStatus});
    res.sendStatus(200);
  } catch (err) {
    console.error(err);
    res.sendStatus(400);
  }
});

router.post("/editTodo", async (req, res) => {
  const {id, task} = req.body;

  try {
    const changeTodo = await Task.findOne({ where: {id: id} });
    await changeTodo.update({task: task});
    res.sendStatus(200);
  } catch (err) {
    console.error(err);
    res.sendStatus(400);
  }
});

module.exports = router;
